SA5 knowledge management next meeting package

1. Extract the entire ZIP while preserving folders.
2. Open index.html in a browser.
3. Click the Word links. Some browsers download the DOCX before opening it.

Files under proposals/ are draft meeting pCRs. Files under technical/ are
internal technical elaborations and examples. TDoc number, submitting source,
and target consolidated TR version must be completed before submission.

The HTML and Word links are relative and work after moving the extracted
package to another computer. The _qa folder used for internal page review is
not included in the ZIP.
